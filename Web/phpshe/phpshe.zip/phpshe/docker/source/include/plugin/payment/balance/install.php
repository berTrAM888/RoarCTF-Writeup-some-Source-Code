<?php
$config['name'] = '余额支付';
$config['type'] = 'balance';
$config['desc'] = '使用帐户余额支付，只有注册会员才能使用';
return $config;
?>