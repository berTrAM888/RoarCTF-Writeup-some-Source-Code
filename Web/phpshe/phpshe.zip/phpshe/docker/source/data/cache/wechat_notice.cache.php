<?php
return unserialize('a:4:{s:9:"order_add";a:2:{s:4:"user";a:10:{s:9:"notice_id";s:1:"1";s:11:"notice_name";s:12:"用户下单";s:11:"notice_type";s:9:"order_add";s:10:"notice_obj";s:4:"user";s:10:"notice_tpl";s:15:"OPENTM202297555";s:12:"notice_tplid";s:0:"";s:16:"notice_industry1";s:8:"IT科技";s:16:"notice_industry2";s:22:"互联网|电子商务";s:14:"notice_example";s:198:"亲，您的订单已创建成功，请及时付款
订单号：180621101215088
商品名称：iPhoneX 64GB 深空灰色
订购数量：1台
订单总额：5980元
付款方式：微信支付
";s:12:"notice_state";s:1:"0";}s:5:"admin";a:10:{s:9:"notice_id";s:1:"5";s:11:"notice_name";s:12:"用户下单";s:11:"notice_type";s:9:"order_add";s:10:"notice_obj";s:5:"admin";s:10:"notice_tpl";s:15:"OPENTM202297555";s:12:"notice_tplid";s:0:"";s:16:"notice_industry1";s:8:"IT科技";s:16:"notice_industry2";s:22:"互联网|电子商务";s:14:"notice_example";s:207:"您好，您收到了一个新订单
订单号：180621101215088
商品名称：iPhoneX 64GB 深空灰色
订购数量：1台
订单总额：5980元
付款方式：微信支付
付款状态：未支付";s:12:"notice_state";s:1:"0";}}s:9:"order_pay";a:2:{s:4:"user";a:10:{s:9:"notice_id";s:1:"2";s:11:"notice_name";s:12:"订单付款";s:11:"notice_type";s:9:"order_pay";s:10:"notice_obj";s:4:"user";s:10:"notice_tpl";s:15:"OPENTM202183094";s:12:"notice_tplid";s:0:"";s:16:"notice_industry1";s:8:"IT科技";s:16:"notice_industry2";s:22:"互联网|电子商务";s:14:"notice_example";s:238:"亲，您的订单已支付成功，正在为您备货，请耐心等待
付款金额：5980元
商品详情：iPhoneX 64GB 深空灰色
支付方式：微信支付
交易单号：180621101215088
交易时间：2018年6月26日 18:36";s:12:"notice_state";s:1:"0";}s:5:"admin";a:10:{s:9:"notice_id";s:1:"6";s:11:"notice_name";s:12:"订单付款";s:11:"notice_type";s:9:"order_pay";s:10:"notice_obj";s:5:"admin";s:10:"notice_tpl";s:15:"OPENTM400255038";s:12:"notice_tplid";s:0:"";s:16:"notice_industry1";s:8:"IT科技";s:16:"notice_industry2";s:22:"互联网|电子商务";s:14:"notice_example";s:207:"您好，您有一笔订单收款成功
客户账号：简好网络
订单编号：180621101215088
付款金额：5980元
付款时间：2018年6月26日 18:36
商品信息：iPhoneX 64GB 深空灰色
";s:12:"notice_state";s:1:"0";}}s:10:"order_send";a:1:{s:4:"user";a:10:{s:9:"notice_id";s:1:"3";s:11:"notice_name";s:12:"订单发货";s:11:"notice_type";s:10:"order_send";s:10:"notice_obj";s:4:"user";s:10:"notice_tpl";s:15:"OPENTM410090504";s:12:"notice_tplid";s:0:"";s:16:"notice_industry1";s:8:"IT科技";s:16:"notice_industry2";s:22:"互联网|电子商务";s:14:"notice_example";s:239:"亲，您的订单已发货，请注意查收
商品详情：iPhoneX 64GB 深空灰色
发货时间：2018年6月26日 18:36
物流公司：顺丰快递
快递单号：123456789
收货地址：河南省灵宝市新华路简好网络
";s:12:"notice_state";s:1:"0";}}s:11:"order_close";a:1:{s:4:"user";a:10:{s:9:"notice_id";s:1:"4";s:11:"notice_name";s:12:"订单关闭";s:11:"notice_type";s:11:"order_close";s:10:"notice_obj";s:4:"user";s:10:"notice_tpl";s:15:"OPENTM408744504";s:12:"notice_tplid";s:0:"";s:16:"notice_industry1";s:8:"IT科技";s:16:"notice_industry2";s:22:"互联网|电子商务";s:14:"notice_example";s:136:"亲，您的订单已被关闭
商品名称：iPhoneX 64GB 深空灰色
订单编号：180621101215088
关闭原因：超时未付款";s:12:"notice_state";s:1:"0";}}}');
?>