<div class="now">
	<a href="admin.php?mod=tongji" <?php if($act=='index'):?>class="sel"<?php endif;?>>访客统计<i></i></a>
	<a href="admin.php?mod=tongji&act=order" <?php if($act=='order'):?>class="sel"<?php endif;?>>订单统计<i></i></a>
	<a href="admin.php?mod=tongji&act=sell" <?php if($act=='sell'):?>class="sel"<?php endif;?>>热销排行<i></i></a>
	<a href="admin.php?mod=tongji&act=user" <?php if($act=='user'):?>class="sel"<?php endif;?>>消费排行<i></i></a>
	<a href="admin.php?mod=tongji&act=notice" <?php if($act=='notice'):?>class="sel"<?php endif;?>>短信/邮件记录<i></i></a>
	<div class="clear"></div>
</div>