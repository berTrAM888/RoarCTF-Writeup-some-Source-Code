Old trick, a null pointer dereference
If you want to compile the linux kernel yourself, there is a .config file and the commit version.

commit：8fe28cb58bcb235034b64cbbb7550a8a43fd88be